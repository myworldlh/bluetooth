import 'libs/adapter';

App({
    onLaunch() {
    },
    globalData: {}
});
